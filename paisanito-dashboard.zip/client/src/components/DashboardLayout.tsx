import { cn } from "@/lib/utils";
import { BarChart3, FileText, Home, LayoutDashboard, Menu, PieChart, Settings } from "lucide-react";
import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "./ui/button";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";

interface DashboardLayoutProps {
  children: React.ReactNode;
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const [location] = useLocation();
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const navItems = [
    { icon: LayoutDashboard, label: "Panel General", href: "/" },
    { icon: BarChart3, label: "Ventas", href: "/ventas" },
    { icon: PieChart, label: "Marketing", href: "/marketing" },
    { icon: FileText, label: "Reporte XETRO", href: "/reporte" },
  ];

  const NavContent = () => (
    <div className="flex flex-col h-full py-6">
      <div className="px-6 mb-8">
        <h1 className="text-2xl font-display font-bold text-primary tracking-tight">
          Los Paisanito
        </h1>
        <p className="text-sm text-muted-foreground font-medium mt-1">
          Panel de Control
        </p>
      </div>
      
      <nav className="flex-1 px-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.href} href={item.href}>
              <Button
                variant="ghost"
                className={cn(
                  "w-full justify-start gap-3 font-medium text-base h-12 transition-all duration-200",
                  isActive 
                    ? "bg-primary text-primary-foreground neo-shadow hover:bg-primary hover:text-primary-foreground translate-x-1" 
                    : "hover:bg-accent hover:text-accent-foreground"
                )}
              >
                <item.icon className="w-5 h-5" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="px-4 mt-auto">
        <Button variant="outline" className="w-full justify-start gap-3 border-2">
          <Settings className="w-5 h-5" />
          Configuración
        </Button>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-background flex">
      {/* Desktop Sidebar */}
      <aside className="hidden lg:block w-64 border-r-2 border-border bg-sidebar fixed h-full z-30">
        <NavContent />
      </aside>

      {/* Mobile Header */}
      <div className="lg:hidden fixed top-0 left-0 right-0 h-16 border-b-2 border-border bg-background z-40 flex items-center px-4 justify-between">
        <span className="font-display font-bold text-lg">Los Paisanito</span>
        <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon">
              <Menu className="w-6 h-6" />
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="p-0 w-64 border-r-2 border-border">
            <NavContent />
          </SheetContent>
        </Sheet>
      </div>

      {/* Main Content */}
      <main className="flex-1 lg:ml-64 pt-16 lg:pt-0 min-h-screen transition-all duration-300">
        <div className="container py-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
          {children}
        </div>
      </main>
    </div>
  );
}
