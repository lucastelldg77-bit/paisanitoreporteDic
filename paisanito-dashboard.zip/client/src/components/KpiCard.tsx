import { cn } from "@/lib/utils";
import { ArrowDownRight, ArrowUpRight, LucideIcon } from "lucide-react";

interface KpiCardProps {
  title: string;
  value: string | number;
  icon: LucideIcon;
  trend?: number;
  trendLabel?: string;
  className?: string;
  color?: "primary" | "secondary" | "accent" | "destructive";
}

export function KpiCard({ 
  title, 
  value, 
  icon: Icon, 
  trend, 
  trendLabel = "vs mes anterior",
  className,
  color = "secondary"
}: KpiCardProps) {
  const isPositive = trend && trend > 0;
  
  const colorStyles = {
    primary: "bg-primary text-primary-foreground",
    secondary: "bg-card text-card-foreground",
    accent: "bg-accent text-accent-foreground",
    destructive: "bg-destructive text-destructive-foreground",
  };

  return (
    <div className={cn(
      "neo-card p-6 flex flex-col justify-between h-full min-h-[160px] relative overflow-hidden group",
      color === "secondary" ? "bg-card" : colorStyles[color],
      className
    )}>
      <div className="flex justify-between items-start mb-4">
        <h3 className={cn(
          "text-sm font-bold uppercase tracking-wider opacity-80",
          color === "secondary" ? "text-muted-foreground" : "text-current"
        )}>
          {title}
        </h3>
        <div className={cn(
          "p-2 rounded-md border-2 border-current",
          color === "secondary" ? "bg-accent/50 border-border" : "bg-white/20 border-white/40"
        )}>
          <Icon className="w-5 h-5" />
        </div>
      </div>
      
      <div className="space-y-1 relative z-10">
        <div className="text-3xl font-display font-bold tracking-tight">
          {value}
        </div>
        
        {trend !== undefined && (
          <div className="flex items-center gap-2 text-sm font-medium">
            <span className={cn(
              "flex items-center gap-1 px-1.5 py-0.5 rounded text-xs border border-current",
              isPositive 
                ? (color === "secondary" ? "bg-green-100 text-green-700 border-green-200" : "bg-white/20")
                : (color === "secondary" ? "bg-red-100 text-red-700 border-red-200" : "bg-white/20")
            )}>
              {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
              {Math.abs(trend)}%
            </span>
            <span className="opacity-70 text-xs">{trendLabel}</span>
          </div>
        )}
      </div>

      {/* Decorative background element */}
      <Icon className="absolute -bottom-4 -right-4 w-24 h-24 opacity-5 rotate-12 group-hover:scale-110 transition-transform duration-500" />
    </div>
  );
}
