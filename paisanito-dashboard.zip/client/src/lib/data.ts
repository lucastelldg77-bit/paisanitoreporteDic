// Datos procesados del análisis de Los Paisanito
// Método XETRO

export const dashboardData = {
  metricas_generales: {
    total_pedidos: 1618,
    total_facturado: 102153882.00,
    ticket_promedio: 91782.46,
    inversion_pauta: 611380.58,
    roi: 16608.7,
    tasa_conversion: 142.3,
    costo_por_pedido: 377.86,
    conversaciones_iniciadas: 1137,
    // Ventas completadas (Pedido realizado + Confirmado + En Preparación + Listo + En Camino + Entregado)
    ventas_completadas: 512,
    monto_ventas_completadas: 44154910.00,
    // Pendientes
    pedidos_pendientes: 998,
    monto_pendientes: 53069776.00,
    // Cancelados
    pedidos_cancelados: 60,
    monto_cancelados: 5223246.00
  },
  // Estados de VENTAS COMPLETADAS
  estados_ventas_completadas: [
    { name: "Pedido realizado", value: 295, color: "var(--color-chart-4)" },
    { name: "Confirmado", value: 189, color: "var(--color-chart-2)" },
    { name: "En Preparación", value: 25, color: "var(--color-chart-1)" },
    { name: "Listo para entregar", value: 0, color: "var(--color-chart-5)" },
    { name: "En Camino", value: 0, color: "var(--color-chart-4)" },
    { name: "Entregado", value: 3, color: "var(--color-chart-5)" }
  ],
  // Estados PENDIENTES y CANCELADOS (por aparte)
  estados_otros: [
    { name: "Pendiente", value: 998, color: "var(--color-muted-foreground)", type: "pending" },
    { name: "Cancelado", value: 60, color: "var(--color-destructive)", type: "cancelled" }
  ],
  // Todos los estados (para referencia)
  estados_pedidos: [
    { name: "Pendiente", value: 998, color: "var(--color-muted-foreground)" },
    { name: "Pedido realizado", value: 295, color: "var(--color-chart-4)" },
    { name: "Confirmado", value: 189, color: "var(--color-chart-2)" },
    { name: "Cancelado", value: 60, color: "var(--color-destructive)" },
    { name: "En Preparación", value: 25, color: "var(--color-chart-1)" },
    { name: "Entregado", value: 3, color: "var(--color-chart-5)" }
  ],
  productos_top: [
    { name: "CAJÓN DE POLLO PROMO N7", value: 896 },
    { name: "PATA MUSLO PROMO X 15 KG", value: 706 },
    { name: "CAJÓN DE POLLO PROMO N6", value: 437 },
    { name: "FILET PROMO X 15 KG", value: 250 },
    { name: "PAPAS BASTÓN BEM BRASIL 15kg", value: 138 },
    { name: "PAPAS NOISETT BEM BRASIL 10,5 kg", value: 76 },
    { name: "PAN RALLADO (RALLADITO)", value: 51 },
    { name: "PATITAS DE POLLO X5 KG", value: 43 },
    { name: "DINOS DE POLLO X5 KG", value: 31 },
    { name: "PATITAS DE POLLO JAMON Y QUESO", value: 27 }
  ],
  dias_semana: [
    { name: "Lunes", value: 233 },
    { name: "Martes", value: 364 },
    { name: "Miércoles", value: 260 },
    { name: "Jueves", value: 249 },
    { name: "Viernes", value: 282 },
    { name: "Sábado", value: 179 },
    { name: "Domingo", value: 3 }
  ],
  campañas: [
    {
      nombre: "Campaña Catalogo Francisco de Aguirre",
      inversion: 240256.57,
      conversaciones: 9,
      costo_conv: 26695.17,
      eficiencia: "Baja"
    },
    {
      nombre: "Campaña Catalogo - Central",
      inversion: 207101.02,
      conversaciones: 10,
      costo_conv: 20710.10,
      eficiencia: "Baja"
    },
    {
      nombre: "Campaña nueva - Casa Central - Bot",
      inversion: 103680.65,
      conversaciones: 739,
      costo_conv: 140.30,
      eficiencia: "Alta"
    },
    {
      nombre: "Influencer con codigo",
      inversion: 41509.00,
      conversaciones: 251,
      costo_conv: 165.37,
      eficiencia: "Alta"
    },
    {
      nombre: "Campaña Carne-BOT -Central y Francisco",
      inversion: 18833.34,
      conversaciones: 128,
      costo_conv: 147.14,
      eficiencia: "Alta"
    }
  ],
  xetro_scores: {
    experiencia: 40,
    emocion: 65,
    trafico: 50,
    retencion: 30,
    optimizacion: 20
  }
};
