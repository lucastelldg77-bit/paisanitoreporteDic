import { DashboardLayout } from "@/components/DashboardLayout";
import { Streamdown } from "streamdown";

const reporteContent = `
# Informe de Consultoría: Método XETRO para Los Paisanito

**Fecha:** 13 de enero de 2026
**Autor:** Manus AI, Consultor Senior en Marketing Digital y Análisis de Negocio

---

## 1. Introducción Ejecutiva

El presente informe ofrece un diagnóstico integral del negocio de **Los Paisanito**, aplicando el **Método XETRO** (Experiencia, Emoción, Tráfico, Retención y Optimización). A partir del análisis de los datos de pedidos y pauta publicitaria de diciembre de 2025, se han identificado oportunidades críticas y se proponen una serie de mejoras accionables con el objetivo de optimizar la rentabilidad, la eficiencia operativa y la experiencia del cliente.

El análisis revela una operación con un alto volumen de demanda y un retorno de la inversión (ROI) publicitaria excepcionalmente alto. Sin embargo, se observan deficiencias significativas en el proceso de gestión de pedidos y una gran disparidad en el rendimiento de las campañas de marketing, lo que indica un potencial de crecimiento sustancial si se implementan las optimizaciones correctas.

## 2. Diagnóstico General del Negocio

A continuación, se presenta una tabla resumen con las métricas clave que fundamentan este análisis.

| Métrica Clave | Valor | Observación |
| :--- | :--- | :--- |
| **Total Facturado** | $102,153,882.00 | Ingresos robustos que indican una fuerte demanda del mercado. |
| **Total de Pedidos** | 1,618 | Alto volumen de transacciones durante el período analizado. |
| **Ticket Promedio** | $91,782.46 | Valor de compra promedio saludable por transacción. |
| **Inversión en Pauta** | $611,380.58 | Inversión significativa en la adquisición de clientes vía Meta Ads. |
| **Retorno de la Inversión (ROI)** | **16,608.7%** | Extraordinariamente alto, pero probablemente inflado por problemas de atribución. |
| **Conversaciones Iniciadas** | 1,137 | Volumen considerable de prospectos generados por la pauta. |
| **Tasa de Conversión (Pedidos/Conv.)** | **142.3%** | Métrica superior al 100%, lo que indica una inconsistencia en los datos. |
| **Costo por Pedido (CPP)** | $377.86 | Costo de adquisición de cliente aparentemente bajo. |

> **Advertencia sobre la Integridad de los Datos:** La tasa de conversión superior al 100% sugiere que no todos los pedidos están siendo correctamente atribuidos a las conversaciones de la pauta publicitaria. Es probable que un número significativo de pedidos provenga de otros canales (orgánicos, directos, recurrentes) o que una sola conversación genere múltiples pedidos. Es crucial implementar un sistema de seguimiento y atribución más preciso para obtener una visión real del rendimiento.

## 3. Análisis con el Método XETRO

### 3.1. Experiencia (X)

La experiencia del cliente presenta fricciones importantes que, de no ser atendidas, podrían limitar el crecimiento y afectar la percepción de la marca.

*   **Proceso de Pedido:** El hallazgo más crítico es que el **61.7% de los pedidos se encuentran en estado "Pendiente"**. Sumado al 18.2% en "Pedido realizado", esto significa que casi el 80% de los clientes no tienen certeza sobre el estado de su compra tras iniciarla. Esta falta de confirmación y seguimiento genera incertidumbre y una mala experiencia, lo que probablemente contribuye a la tasa de cancelación del 3.7%.
*   **Formas de Pago:** La gran mayoría de los pedidos (1,545 de 1,618) no tienen una forma de pago especificada. Esto representa una grave deficiencia en la recolección de datos y sugiere una experiencia de pago poco clara o manual para el cliente.
*   **Pedidos Entregados:** Únicamente el 0.2% de los pedidos figuran como "Entregado". Esta cifra es inverosímil y apunta a una falta de actualización en el sistema de gestión de estados, impidiendo medir la satisfacción final y la eficiencia logística.

### 3.2. Emoción (E)

Aunque los datos no miden directamente la emoción, podemos inferir aspectos clave que influyen en la percepción de la marca.

*   **Positivo:** El uso de campañas con influencers ("Influencer con codigo") es una táctica acertada para generar confianza y una conexión más personal con la audiencia. Los nombres de los productos, con un fuerte énfasis en "PROMO", apelan a un sentimiento de oportunidad y ahorro, lo que resuena con un público que busca valor.
*   **Negativo:** La incertidumbre generada por el alto volumen de pedidos "Pendientes" es una fuente garantizada de **frustración y ansiedad** para el cliente. Una comunicación proactiva y transparente sobre el estado del pedido es fundamental para transformar una posible emoción negativa en confianza.

### 3.3. Tráfico (T)

El tráfico es generado principalmente por Meta Ads, pero la eficiencia de esta inversión es extremadamente desigual.

*   **Rendimiento de Campañas:** Existe una polarización alarmante en el costo por conversación:
    *   **Campañas Eficientes:** La "Campaña nueva - Casa Central - Bot" ($140.30/conv.) y la de "Influencer con codigo" ($165.37/conv.) son altamente efectivas.
    *   **Campañas Ineficientes:** Las campañas de "Catálogo" son un sumidero de recursos, con costos por conversación que superan los $20,000. **Están gastando más del 73% del presupuesto para generar menos del 2% de las conversaciones.**

| Campaña | Inversión | Conversaciones | Costo por Conversación |
| :--- | :--- | :--- | :--- |
| Campaña nueva - Casa Central - Bot | $103,680.65 | 739 | **$140.30** |
| Influencer con codigo | $41,509.00 | 251 | **$165.37** |
| Campaña Carne-BOT -Central y Francisco | $18,833.34 | 128 | **$147.14** |
| Campaña Catalogo - Central 25 de nov. | $207,101.02 | 10 | *$20,710.10* |
| Campaña Catalogo Fco. de Aguirre | $240,256.57 | 9 | *$26,695.17* |

### 3.4. Retención (R)

La retención de clientes es imposible de medir con los datos actuales, pero el modelo de negocio (venta de productos consumibles como el pollo) tiene un altísimo potencial para la compra recurrente.

*   **Obstáculos para la Retención:** La mala experiencia en el proceso de compra (pedidos pendientes, falta de información) es el principal enemigo de la retención. Un cliente frustrado es un cliente que no vuelve.
*   **Productos Populares:** Productos como "CAJÓN DE POLLO PROMO N7" y "PATA MUSLO PROMO X 15 KG" son los más vendidos y representan una excelente oportunidad para incentivar la recompra a través de suscripciones o recordatorios automáticos.

### 3.5. Optimización (O)

Basado en el análisis XETR, se proponen las siguientes acciones de optimización, priorizadas por impacto y viabilidad.

#### **Acciones Inmediatas (Quick Wins)**

1.  **Redirección de Presupuesto de Pauta:**
    *   **Pausar inmediatamente** las dos "Campaña Catálogo". Esta acción liberará $447,357.59 (73% del presupuesto) que están siendo invertidos de forma ineficiente.
    *   **Reinvertir** una porción de ese presupuesto en las campañas de "Bot" e "Influencer", que han demostrado un rendimiento excepcional. Escalar estas campañas de forma controlada para maximizar la generación de prospectos a bajo costo.

2.  **Optimización del Proceso de Pedidos:**
    *   Implementar un sistema de **confirmación automática** (vía email o WhatsApp) en el momento en que se realiza un pedido. Esto reduce la incertidumbre del cliente y mueve el pedido del estado "Pendiente" a "Confirmado".
    *   Establecer un protocolo para actualizar el estado de los pedidos a "En Preparación", "En Camino" y, crucialmente, **"Entregado"**. Sin este último paso, es imposible analizar el ciclo de vida completo del cliente.

#### **Acciones Estratégicas (Mediano Plazo)**

3.  **Mejora de la Captura de Datos:**
    *   Integrar pasarelas de pago claras (Mercado Pago, transferencias bancarias con CBU visible, etc.) y asegurar que la **forma de pago se registre correctamente** en el sistema. Esto no solo mejora la experiencia del usuario, sino que proporciona datos valiosos para el análisis financiero.
    *   Implementar un **sistema de atribución de conversiones** más sofisticado (ej. Píxel de Meta, API de conversiones) para entender qué campañas generan ventas reales y no solo conversaciones.

4.  **Estrategia de Retención:**
    *   Una vez optimizado el proceso de pedidos, crear campañas de email o WhatsApp marketing dirigidas a clientes que ya han comprado. Ofrecer descuentos por recompra en sus productos favoritos (ej. "Tu próximo Cajón de Pollo N7 con 10% de descuento").
    *   Analizar la frecuencia de compra para identificar a los clientes más leales y crear un programa de fidelización.

## 4. Conclusión

Los Paisanito se encuentra en una posición envidiable con una fuerte demanda de sus productos y una operación de marketing que, en ciertos segmentos, es extremadamente rentable. Sin embargo, el crecimiento futuro está siendo frenado por ineficiencias operativas críticas y una mala asignación de recursos publicitarios.

Al reenfocar la inversión publicitaria en las campañas de alto rendimiento y solucionar las fricciones en la experiencia de compra, Los Paisanito no solo mejorará su rentabilidad a corto plazo, sino que construirá una base sólida para la lealtad y retención de clientes a largo plazo. La implementación de estas recomendaciones transformará el potencial actual en un crecimiento sostenible y medible.
`;

export default function Reporte() {
  return (
    <DashboardLayout>
      <div className="max-w-4xl mx-auto">
        <div className="neo-card p-8 md:p-12 bg-card">
          <article className="prose prose-lg max-w-none prose-headings:font-display prose-headings:font-bold prose-h1:text-4xl prose-h2:text-2xl prose-h2:mt-8 prose-p:text-muted-foreground prose-strong:text-foreground prose-blockquote:border-l-4 prose-blockquote:border-primary prose-blockquote:bg-accent/30 prose-blockquote:py-2 prose-blockquote:px-4 prose-blockquote:rounded-r-lg prose-table:border-collapse prose-th:bg-accent/50 prose-th:p-3 prose-td:p-3 prose-td:border-b prose-td:border-border">
            <Streamdown>{reporteContent}</Streamdown>
          </article>
        </div>
      </div>
    </DashboardLayout>
  );
}
