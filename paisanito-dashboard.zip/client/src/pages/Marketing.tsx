import { DashboardLayout } from "@/components/DashboardLayout";
import { KpiCard } from "@/components/KpiCard";
import { dashboardData } from "@/lib/data";
import { formatCurrency } from "@/lib/utils";
import { ArrowRight, BarChart3, MessageSquare, Target, TrendingUp } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export default function Marketing() {
  const { metricas_generales, campañas } = dashboardData;

  // Ordenar campañas por eficiencia (costo por conversación ascendente)
  const campañasOrdenadas = [...campañas].sort((a, b) => a.costo_conv - b.costo_conv);

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-foreground">
              Rendimiento de Marketing
            </h2>
            <p className="text-muted-foreground">
              Análisis de eficiencia de campañas Meta Ads
            </p>
          </div>
        </div>

        {/* Marketing KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <KpiCard
            title="Inversión Total"
            value={formatCurrency(metricas_generales.inversion_pauta)}
            icon={Target}
            color="secondary"
          />
          <KpiCard
            title="Costo por Pedido"
            value={formatCurrency(metricas_generales.costo_por_pedido)}
            icon={TrendingUp}
            color="secondary"
          />
          <KpiCard
            title="Conversaciones"
            value={metricas_generales.conversaciones_iniciadas}
            icon={MessageSquare}
            color="primary"
          />
          <KpiCard
            title="ROI Estimado"
            value={`${metricas_generales.roi.toLocaleString()}%`}
            icon={BarChart3}
            color="accent"
          />
        </div>

        {/* Campaign Efficiency Analysis */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 neo-card p-6 bg-card">
            <h3 className="text-lg font-bold font-display mb-6">Costo por Conversación (Menor es mejor)</h3>
            <div className="h-[400px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={campañasOrdenadas} layout="vertical" margin={{ left: 0, right: 40, top: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="var(--color-border)" opacity={0.1} />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="nombre" 
                    type="category" 
                    width={180}
                    tick={{ fill: 'var(--color-foreground)', fontSize: 11, fontWeight: 500 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip 
                    cursor={{ fill: 'var(--color-accent)', opacity: 0.2 }}
                    contentStyle={{ 
                      backgroundColor: 'var(--color-card)', 
                      border: '2px solid var(--color-border)',
                      borderRadius: '8px',
                      boxShadow: '4px 4px 0px 0px var(--color-border)'
                    }}
                    formatter={(value: number) => [formatCurrency(value), 'Costo por Conv.']}
                  />
                  <Bar dataKey="costo_conv" radius={[0, 4, 4, 0]} barSize={32}>
                    {campañasOrdenadas.map((entry, index) => (
                      <Cell 
                        key={`cell-${index}`} 
                        fill={entry.eficiencia === 'Alta' ? 'var(--color-chart-2)' : 'var(--color-destructive)'} 
                      />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Insights Panel */}
          <div className="space-y-6">
            <div className="neo-card p-6 bg-accent/30 border-dashed">
              <h3 className="text-lg font-bold font-display mb-4 text-destructive">Ineficiencia Detectada</h3>
              <p className="text-sm text-muted-foreground mb-4">
                Las campañas de "Catálogo" tienen un costo por conversación <strong>150 veces mayor</strong> que las campañas de Bot.
              </p>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Costo Campaña Catálogo:</span>
                  <span className="font-bold text-destructive">$26,695</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Costo Campaña Bot:</span>
                  <span className="font-bold text-green-600">$140</span>
                </div>
              </div>
            </div>

            <div className="neo-card p-6 bg-primary text-primary-foreground">
              <h3 className="text-lg font-bold font-display mb-2">Recomendación</h3>
              <p className="text-sm opacity-90 mb-4">
                Pausar inmediatamente las campañas de catálogo y redistribuir el presupuesto a la campaña "Casa Central - Bot".
              </p>
              <button className="w-full py-2 bg-white text-primary font-bold rounded flex items-center justify-center gap-2 hover:bg-white/90 transition-colors">
                Ver detalle en reporte <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
