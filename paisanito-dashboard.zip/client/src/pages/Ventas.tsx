import { DashboardLayout } from "@/components/DashboardLayout";
import { dashboardData } from "@/lib/data";
import { formatCurrency, formatNumber } from "@/lib/utils";
import { Bar, BarChart, CartesianGrid, Cell, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export default function Ventas() {
  const { productos_top, estados_pedidos } = dashboardData;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-foreground">
              Análisis de Ventas
            </h2>
            <p className="text-muted-foreground">
              Detalle de productos más vendidos y estados de pedidos
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Top Products Chart */}
          <div className="lg:col-span-2 neo-card p-6 bg-card">
            <h3 className="text-lg font-bold font-display mb-6">Top 10 Productos Más Vendidos</h3>
            <div className="h-[500px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={productos_top} layout="vertical" margin={{ left: 20, right: 20, top: 0, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="var(--color-border)" opacity={0.1} />
                  <XAxis type="number" hide />
                  <YAxis 
                    dataKey="name" 
                    type="category" 
                    width={200}
                    tick={{ fill: 'var(--color-foreground)', fontSize: 12, fontWeight: 500 }}
                    axisLine={false}
                    tickLine={false}
                  />
                  <Tooltip 
                    cursor={{ fill: 'var(--color-accent)', opacity: 0.2 }}
                    contentStyle={{ 
                      backgroundColor: 'var(--color-card)', 
                      border: '2px solid var(--color-border)',
                      borderRadius: '8px',
                      boxShadow: '4px 4px 0px 0px var(--color-border)'
                    }}
                    formatter={(value: number) => [`${value} unidades`, 'Ventas']}
                  />
                  <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={24}>
                    {productos_top.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index < 3 ? 'var(--color-primary)' : 'var(--color-chart-2)'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Order Status Detail */}
          <div className="space-y-6">
            <div className="neo-card p-6 bg-card">
              <h3 className="text-lg font-bold font-display mb-4">Resumen de Estados</h3>
              <div className="space-y-4">
                {estados_pedidos.map((estado, index) => (
                  <div key={index} className="flex items-center justify-between p-3 rounded-lg hover:bg-accent/50 transition-colors border border-transparent hover:border-border/10">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-3 h-3 rounded-full" 
                        style={{ backgroundColor: estado.color }}
                      />
                      <span className="font-medium text-sm">{estado.name}</span>
                    </div>
                    <div className="text-right">
                      <div className="font-bold font-display">{formatNumber(estado.value)}</div>
                      <div className="text-xs text-muted-foreground">
                        {((estado.value / 1618) * 100).toFixed(1)}%
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="neo-card p-6 bg-primary text-primary-foreground">
              <h3 className="text-lg font-bold font-display mb-2">Producto Estrella</h3>
              <div className="text-3xl font-bold mb-1">Cajón de Pollo N7</div>
              <div className="text-sm opacity-90 mb-4">896 unidades vendidas</div>
              <div className="w-full bg-black/10 h-2 rounded-full overflow-hidden">
                <div className="bg-white h-full w-[55%]"></div>
              </div>
              <p className="text-xs mt-2 opacity-80">Representa el 55% del volumen total de ventas</p>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
