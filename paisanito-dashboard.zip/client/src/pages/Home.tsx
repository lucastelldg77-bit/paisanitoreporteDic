import { DashboardLayout } from "@/components/DashboardLayout";
import { KpiCard } from "@/components/KpiCard";
import { dashboardData } from "@/lib/data";
import { formatCurrency } from "@/lib/utils";
import { Activity, AlertCircle, CheckCircle2, DollarSign, ShoppingBag, TrendingUp, Users, XCircle } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Cell, Legend, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";

export default function Home() {
  const { metricas_generales, estados_ventas_completadas, estados_otros, dias_semana } = dashboardData;

  return (
    <DashboardLayout>
      <div className="space-y-8">
        {/* Header Section */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-display font-bold text-foreground">
              Resumen General
            </h2>
            <p className="text-muted-foreground">
              Vista general del rendimiento de diciembre 2025
            </p>
          </div>
          <div className="flex items-center gap-2 bg-accent/50 px-4 py-2 rounded-lg border-2 border-border">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-sm font-medium">Datos actualizados: 13 Ene 2026</span>
          </div>
        </div>

        {/* VENTAS COMPLETADAS Section */}
        <div className="space-y-4">
          <h3 className="text-xl font-display font-bold text-foreground flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-green-600" />
            Ventas Completadas
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <KpiCard
              title="Monto Vendido"
              value={formatCurrency(metricas_generales.monto_ventas_completadas)}
              icon={DollarSign}
              trend={12.5}
              color="primary"
            />
            <KpiCard
              title="Pedidos Completados"
              value={metricas_generales.ventas_completadas}
              icon={ShoppingBag}
              trend={8.2}
            />
            <KpiCard
              title="Ticket Promedio"
              value={formatCurrency(metricas_generales.monto_ventas_completadas / metricas_generales.ventas_completadas)}
              icon={TrendingUp}
              trend={-2.1}
            />
            <KpiCard
              title="% del Total"
              value={`${((metricas_generales.ventas_completadas / metricas_generales.total_pedidos) * 100).toFixed(1)}%`}
              icon={Activity}
              trend={5.3}
            />
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Sales by Day Chart */}
          <div className="lg:col-span-2 neo-card p-6 bg-card">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold font-display flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Volumen de Pedidos por Día
              </h3>
            </div>
            <div className="h-[300px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dias_semana}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--color-border)" opacity={0.1} />
                  <XAxis 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{ fill: 'var(--color-muted-foreground)', fontSize: 12 }}
                  />
                  <Tooltip 
                    cursor={{ fill: 'var(--color-accent)', opacity: 0.2 }}
                    contentStyle={{ 
                      backgroundColor: 'var(--color-card)', 
                      border: '2px solid var(--color-border)',
                      borderRadius: '8px',
                      boxShadow: '4px 4px 0px 0px var(--color-border)'
                    }}
                  />
                  <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                    {dias_semana.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={index % 2 === 0 ? 'var(--color-primary)' : 'var(--color-chart-2)'} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Ventas Completadas Status Chart */}
          <div className="neo-card p-6 bg-card flex flex-col">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold font-display flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-chart-2" />
                Estados Completados
              </h3>
            </div>
            <div className="h-[300px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={estados_ventas_completadas}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {estados_ventas_completadas.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="var(--color-border)" strokeWidth={1} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ 
                      backgroundColor: 'var(--color-card)', 
                      border: '2px solid var(--color-border)',
                      borderRadius: '8px',
                      boxShadow: '4px 4px 0px 0px var(--color-border)'
                    }}
                  />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" />
                </PieChart>
              </ResponsiveContainer>
              
              {/* Center Text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-8">
                <span className="text-3xl font-bold font-display">{metricas_generales.ventas_completadas}</span>
                <span className="text-xs text-muted-foreground uppercase tracking-wider">Completados</span>
              </div>
            </div>
          </div>
        </div>

        {/* PENDIENTES Y CANCELADOS Section */}
        <div className="space-y-4">
          <h3 className="text-xl font-display font-bold text-foreground flex items-center gap-2">
            <AlertCircle className="w-6 h-6 text-yellow-600" />
            Pendientes y Cancelados
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <KpiCard
              title="Monto Pendiente"
              value={formatCurrency(metricas_generales.monto_pendientes)}
              icon={AlertCircle}
              color="secondary"
            />
            <KpiCard
              title="Pedidos Pendientes"
              value={metricas_generales.pedidos_pendientes}
              icon={ShoppingBag}
              color="secondary"
            />
            <KpiCard
              title="Monto Cancelado"
              value={formatCurrency(metricas_generales.monto_cancelados)}
              icon={XCircle}
              color="destructive"
            />
            <KpiCard
              title="Pedidos Cancelados"
              value={metricas_generales.pedidos_cancelados}
              icon={XCircle}
              color="destructive"
            />
          </div>
        </div>

        {/* Alerts Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="neo-card p-6 bg-accent/30 border-dashed">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-yellow-100 rounded-lg border-2 border-yellow-200 text-yellow-600">
                <AlertCircle className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-yellow-700 mb-1">Pedidos Pendientes</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  <strong>998 pedidos (61.7%)</strong> permanecen en estado "Pendiente". Esto genera incertidumbre en el cliente y afecta la tasa de recompra.
                </p>
                <button className="text-sm font-bold underline decoration-2 underline-offset-4 hover:text-primary transition-colors">
                  Ver detalles de pedidos pendientes →
                </button>
              </div>
            </div>
          </div>

          <div className="neo-card p-6 bg-accent/30 border-dashed">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-chart-4/10 rounded-lg border-2 border-chart-4/20 text-chart-4">
                <DollarSign className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-lg font-bold text-chart-4">Oportunidad de Ahorro</h4>
                <p className="text-sm text-muted-foreground mb-4">
                  Las campañas de "Catálogo" consumen el <strong>73%</strong> del presupuesto pero generan menos del 2% de las conversaciones.
                </p>
                <button className="text-sm font-bold underline decoration-2 underline-offset-4 hover:text-primary transition-colors">
                  Ver análisis de marketing →
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}
